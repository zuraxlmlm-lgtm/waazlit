# Starter Web
Template website statis siap pakai (HTML, CSS, JS) — ringan, responsif, dan aksesibel.

## Struktur
```
starter-website/
├─ index.html
├─ about.html
├─ contact.html
├─ privacy.html
└─ assets/
   ├─ css/style.css
   ├─ js/main.js
   └─ img/ (logo.svg, hero.svg, favicon.svg, og-image.png)
```

## Cara Pakai
1. Ekstrak folder ini.
2. Buka `index.html` di browser.
3. Edit konten, warna, dan komponen sesuai kebutuhan.

## Lisensi
MIT — bebas dipakai untuk proyek apapun.