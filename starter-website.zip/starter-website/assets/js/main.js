// ====== Starter Web JS ======
const qs = (s, scp=document)=> scp.querySelector(s);

function setupMenu(){
  const btn = qs('.menu-toggle');
  const nav = qs('#nav');
  if(!btn || !nav) return;
  btn.addEventListener('click', ()=>{
    const expanded = btn.getAttribute('aria-expanded') === 'true';
    btn.setAttribute('aria-expanded', String(!expanded));
    nav.classList.toggle('open');
  });
}

function setupContactForm(){
  const form = qs('#contactForm');
  if(!form) return;
  const msg = qs('#contactMsg');
  form.addEventListener('submit', (e)=>{
    e.preventDefault();
    const data = new FormData(form);
    // Simple validation
    if(!(data.get('name') && data.get('email') && data.get('message'))){
      msg.textContent = 'Mohon lengkapi semua field.';
      msg.style.color = 'var(--warn)';
      return;
    }
    msg.textContent = 'Terkirim! (simulasi)';
    msg.style.color = 'var(--ok)';
    form.reset();
  });
}

function setupNewsletter(){
  const form = qs('#newsletterForm');
  const msg = qs('#newsMsg');
  if(!form || !msg) return;
  form.addEventListener('submit', (e)=>{
    e.preventDefault();
    const email = qs('#emailNews').value.trim();
    if(!email){
      msg.textContent = 'Masukkan email yang valid.';
      msg.style.color = 'var(--warn)';
      return;
    }
    msg.textContent = 'Berhasil berlangganan! (simulasi)';
    msg.style.color = 'var(--ok)';
    qs('#emailNews').value='';
  });
}

document.addEventListener('DOMContentLoaded', ()=>{
  setupMenu();
  setupContactForm();
  setupNewsletter();
});